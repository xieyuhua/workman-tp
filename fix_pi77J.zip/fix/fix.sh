cp -f validate/Validate.php ../vendor/topthink/think-validate/src/

cp -f oracle/builder/Oracle.php ../vendor/topthink/think-orm/src/db/builder/
cp -f oracle/connector/Oracle.php ../vendor/topthink/think-orm/src/db/connector/
cp -f oracle/BaseBuilder.php ../vendor/topthink/think-orm/src/db/

